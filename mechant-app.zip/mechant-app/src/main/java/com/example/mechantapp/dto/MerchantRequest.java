package com.example.mechantapp.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MerchantRequest {

    private String name;

    private String email;

    private String businessType;

    private String govtId;
}
