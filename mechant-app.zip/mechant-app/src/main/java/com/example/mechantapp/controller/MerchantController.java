package com.example.mechantapp.controller;

import com.example.mechantapp.dto.MerchantRequest;
import com.example.mechantapp.dto.PaymentReq;
import com.example.mechantapp.exception.PaymentGatewayCustomException;
import com.example.mechantapp.response.ApiResponse;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/api/v1")
public class MerchantController {

    @PostMapping("merchant")
    public ResponseEntity<ApiResponse> createMerchant(@RequestBody MerchantRequest merchantRequest) throws Exception {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("Access-Key", "KOEWJGVAKV6JI4F");
        headers.set("Secret-Key", "1V%RQ@1UMZBBY@%");

        HttpEntity<MerchantRequest> request = new HttpEntity<>(merchantRequest, headers);

        RestTemplate restTemplate = new RestTemplate();
        try {
            return restTemplate.postForEntity("http://localhost:8080/api/v1/merchant", request, ApiResponse.class);
        } catch (Exception e) {
            e.printStackTrace();
            throw new PaymentGatewayCustomException("Something went wrong");
        }
    }

    @PostMapping("payment")
    public ResponseEntity<ApiResponse> createPayment(@RequestBody PaymentReq paymentReq) throws Exception {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("Access-Key", "KOEWJGVAKV6JI4F");
        headers.set("Secret-Key", "1V%RQ@1UMZBBY@%");

        HttpEntity<PaymentReq> request = new HttpEntity<>(paymentReq, headers);

        RestTemplate restTemplate = new RestTemplate();
        try {
            return restTemplate.postForEntity("http://localhost:8080/api/v1/payment", request, ApiResponse.class);
        } catch (Exception e) {
            e.printStackTrace();
            throw new PaymentGatewayCustomException("Something went wrong");
        }
    }

    @GetMapping("/payment")
    public ResponseEntity<ApiResponse> getPayment(@RequestParam String transId) throws Exception {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("Access-Key", "KOEWJGVAKV6JI4F");
        headers.set("Secret-Key", "1V%RQ@1UMZBBY@%");

        HttpEntity<String> requestEntity = new HttpEntity<>(headers);
        RestTemplate restTemplate = new RestTemplate();
        try {
            return restTemplate.exchange(
                    "http://localhost:8080/api/v1/payment-status?transId=" + transId,  // Corrected URL construction
                    HttpMethod.GET,
                    requestEntity,
                    ApiResponse.class
            );
        } catch (Exception e) {
            e.printStackTrace();
            throw new PaymentGatewayCustomException("Something went wrong");
        }
    }
}
