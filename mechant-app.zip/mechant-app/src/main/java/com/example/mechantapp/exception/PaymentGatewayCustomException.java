package com.example.mechantapp.exception;

public class PaymentGatewayCustomException extends Exception {
    public PaymentGatewayCustomException(){}
    public PaymentGatewayCustomException(String message) {
        super(message);
    }
}