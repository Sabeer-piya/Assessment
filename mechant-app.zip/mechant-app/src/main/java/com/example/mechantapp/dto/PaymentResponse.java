package com.example.mechantapp.dto;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class PaymentResponse {

    private String transId;

    private String merchantId;

    private Double totalAmt;

    private String cardType;

    private String cardNo;

    private String cardExpiry;
}
