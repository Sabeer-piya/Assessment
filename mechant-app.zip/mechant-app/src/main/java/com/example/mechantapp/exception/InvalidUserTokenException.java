package com.example.mechantapp.exception;

public class InvalidUserTokenException extends Exception {
	public InvalidUserTokenException(String message) {
		super(message);
	}
}
