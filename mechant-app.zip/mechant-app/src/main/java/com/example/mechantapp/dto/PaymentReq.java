package com.example.mechantapp.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PaymentReq {

    private String merchantUuid;

    private String cardNo;

    private String expiry;

    private Double totalAmt;
}
