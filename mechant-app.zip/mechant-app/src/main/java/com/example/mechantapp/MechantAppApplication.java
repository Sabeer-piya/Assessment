package com.example.mechantapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MechantAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(MechantAppApplication.class, args);
	}

}
