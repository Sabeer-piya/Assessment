package com.example.paymentgateway.service.impl;

import com.example.paymentgateway.dto.MerchantRequest;
import com.example.paymentgateway.dto.PaymentReq;
import com.example.paymentgateway.dto.PaymentResponse;
import com.example.paymentgateway.dto.SecretResponse;
import com.example.paymentgateway.enums.CardType;
import com.example.paymentgateway.enums.PaymentStatus;
import com.example.paymentgateway.exception.PaymentGatewayCustomException;
import com.example.paymentgateway.model.Merchant;
import com.example.paymentgateway.model.Payment;
import com.example.paymentgateway.model.PaymentDetail;
import com.example.paymentgateway.model.SecretCred;
import com.example.paymentgateway.repository.MerchantRepo;
import com.example.paymentgateway.repository.PaymentDetailRepo;
import com.example.paymentgateway.repository.PaymentRepo;
import com.example.paymentgateway.repository.SecretCredRepo;
import com.example.paymentgateway.response.ApiResponse;
import com.example.paymentgateway.service.PaymentService;
import com.example.paymentgateway.utils.Utility;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Service
public class PaymentServiceImpl implements PaymentService {

    private final MerchantRepo merchantRepo;

    private final SecretCredRepo secretCredRepo;

    private final PaymentDetailRepo paymentDetailRepo;

    private final PaymentRepo paymentRepo;

    @Autowired
    public PaymentServiceImpl(MerchantRepo merchantRepo, SecretCredRepo secretCredRepo, PaymentDetailRepo paymentDetailRepo, PaymentRepo paymentRepo) {
        this.merchantRepo = merchantRepo;
        this.secretCredRepo = secretCredRepo;
        this.paymentDetailRepo = paymentDetailRepo;
        this.paymentRepo = paymentRepo;
    }

    @Override
    public ApiResponse createMerchant(MerchantRequest merchantRequest, HttpHeaders headers) throws Exception {
        SecretCred secretCred = validateSecretCredentials(headers);
        validateMerchantRequest(merchantRequest);
        Merchant merchant = setMerchantDataInModel(merchantRequest, secretCred);
        return new ApiResponse(HttpStatus.OK, "success", merchant.getUuid());
    }

    @Override
    public ApiResponse createSecret() {
        SecretResponse secretResponse = setSecretDataInModel();
        return new ApiResponse(HttpStatus.OK, "success", secretResponse);
    }

    @Override
    @Transactional(rollbackFor = {Exception.class, PaymentGatewayCustomException.class})
    public ApiResponse createPayment(PaymentReq paymentReq, HttpHeaders headers) throws Exception{
        SecretCred secretCred = validateSecretCredentials(headers);
        return createPaymentDetailsAndCompletePaymentProcess(paymentReq, secretCred);
    }

    @Override
    public ApiResponse getPayment(String transId, HttpHeaders headers) throws Exception {
        SecretCred secretCred = validateSecretCredentials(headers);
        return setPaymentResponse(transId, secretCred);
    }

    private ApiResponse setPaymentResponse(String transId, SecretCred secretCred) throws Exception{
        Payment payment = paymentRepo.findByTransIdAndPaymentDetailMerchantSecretCred(transId, secretCred).orElseThrow(()-> new PaymentGatewayCustomException("Payment not found"));
        return new ApiResponse(HttpStatus.OK, "success", new PaymentResponse(payment));
    }

    private ApiResponse createPaymentDetailsAndCompletePaymentProcess(PaymentReq paymentReq, SecretCred secretCred) throws Exception {
        CardType cardType = Utility.identifyCardType(paymentReq.getCardNo());
        String transId = Utility.getRandomStringKey(8);
        if (paymentRepo.existsByTransId(transId)) {
            transId = Utility.getRandomStringKey(8);
        }
        PaymentDetail paymentDetail = setPaymentDetails(paymentReq, cardType, secretCred);
        setPayment(paymentReq, paymentDetail, transId, cardType);
        if (cardType.equals(CardType.INVALID)) {
            return new ApiResponse(HttpStatus.OK, "Payment failed", transId);
        } else {
            return new ApiResponse(HttpStatus.OK, "success", transId);
        }
    }

    private PaymentDetail setPaymentDetails(PaymentReq paymentReq, CardType cardType, SecretCred secretCred) throws Exception {
        LocalDate localDate = Utility.getExpiryMonth(paymentReq.getExpiry());
        if (!localDate.isAfter(LocalDate.now())) {
            throw new PaymentGatewayCustomException("Your card is expired");
        }
        String cardNo = paymentReq.getCardNo().replaceAll("\\s","");
        Merchant merchant = merchantRepo.findByUuidAndSecretCred(paymentReq.getMerchantUuid(), secretCred).orElseThrow(()-> new PaymentGatewayCustomException("Merchant not found"));
        return paymentDetailRepo.findByMerchantAndCardNo(merchant, cardNo)
                .orElseGet(() -> {
                    PaymentDetail newPaymentDetail = new PaymentDetail();
                    newPaymentDetail.setCardNo(cardNo);
                    newPaymentDetail.setCardType(cardType);
                    newPaymentDetail.setMerchant(merchant);
                    newPaymentDetail.setCardExpiry(localDate);
                    newPaymentDetail = paymentDetailRepo.save(newPaymentDetail);
                    return newPaymentDetail;
                });
    }

    private void setPayment(PaymentReq paymentReq, PaymentDetail paymentDetail, String transId, CardType cardType) {
        Payment payment = new Payment();
        payment.setPaymentDetail(paymentDetail);
        payment.setTransId(transId);
        payment.setPaidOn(LocalDateTime.now());
        payment.setTotalAmt(paymentReq.getTotalAmt());
        if (cardType.equals(CardType.INVALID)) {
            payment.setStatus(PaymentStatus.FAILED);
        } else {
            payment.setStatus(PaymentStatus.COMPLETED);
        }
        paymentRepo.save(payment);
    }

    private SecretResponse setSecretDataInModel() {
        String uuid = Utility.getRandomStringKey(8);
        String accessKey = Utility.getAccessRandomStringKey(15);
        String secretKey = Utility.getSecretRandomStringKey(15);
        if (merchantRepo.existsByUuid(uuid)) {
            uuid = Utility.getRandomStringKey(8);
        }
        if (secretCredRepo.existsByAccessKey(accessKey)) {
            accessKey = Utility.getAccessRandomStringKey(15);
        }
        if (secretCredRepo.existsBySecretKey(accessKey)) {
            secretKey = Utility.getSecretRandomStringKey(15);
        }
        SecretCred secretCred = new SecretCred();
        secretCred.setUuid(uuid);
        secretCred.setAccessKey(accessKey);
        secretCred.setSecretKey(secretKey);
        secretCred = secretCredRepo.save(secretCred);
        return new SecretResponse(secretCred);
    }

    private Merchant setMerchantDataInModel(MerchantRequest merchantRequest, SecretCred secretCred) {
        String uuid = Utility.getRandomStringKey(8);
        if (merchantRepo.existsByUuid(uuid)) {
            uuid = Utility.getRandomStringKey(8);
        }
        Merchant merchant = new Merchant();
        merchant.setUuid(uuid);
        merchant.setSecretCred(secretCred);
        merchant.setName(merchantRequest.getName());
        merchant.setEmail(merchantRequest.getEmail());
        merchant.setType(merchantRequest.getBusinessType());
        merchant.setGovtId(merchantRequest.getGovtId());
        merchant=merchantRepo.save(merchant);
        return merchant;
    }

    private SecretCred validateSecretCredentials(HttpHeaders headers) throws Exception {
        String accessKey = headers.getFirst("Access-Key");
        String secretKey = headers.getFirst("Secret-Key");
        return secretCredRepo.findByAccessKeyAndSecretKeyAndIsActiveTrue(accessKey, secretKey).orElseThrow(()-> new PaymentGatewayCustomException("You are Unauthorised to access this service"));
    }

    private void validateMerchantRequest(MerchantRequest merchantRequest) throws Exception{
        if (!StringUtils.hasLength(merchantRequest.getName())) {
            throw new PaymentGatewayCustomException("Name is required");
        }

        if (!StringUtils.hasLength(merchantRequest.getGovtId())) {
            throw new PaymentGatewayCustomException("GovtId is required");
        }

        if (!StringUtils.hasLength(merchantRequest.getBusinessType())) {
            throw new PaymentGatewayCustomException("BusinessType is required");
        }

        if (!StringUtils.hasLength(merchantRequest.getEmail())) {
            throw new PaymentGatewayCustomException("Email is required");
        }
    }
}
