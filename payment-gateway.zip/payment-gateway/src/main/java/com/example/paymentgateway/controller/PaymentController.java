package com.example.paymentgateway.controller;

import com.example.paymentgateway.dto.MerchantRequest;
import com.example.paymentgateway.dto.PaymentReq;
import com.example.paymentgateway.response.ApiResponse;
import com.example.paymentgateway.service.PaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RequestMapping("/api/v1")
@RestController
public class PaymentController {

    private final PaymentService paymentService;

    @Autowired
    public PaymentController(PaymentService paymentService) {
        this.paymentService = paymentService;
    }

    @GetMapping("secret")
    public ResponseEntity<ApiResponse> createSecret() throws Exception {
        ApiResponse apiResponse = paymentService.createSecret();
        return new ResponseEntity<>(apiResponse, apiResponse.getStatus());
    }

    @PostMapping("merchant")
    public ResponseEntity<ApiResponse> createMerchant(@RequestBody MerchantRequest merchantRequest, @RequestHeader HttpHeaders headers) throws Exception {
        ApiResponse apiResponse = paymentService.createMerchant(merchantRequest, headers);
        return new ResponseEntity<>(apiResponse, apiResponse.getStatus());
    }

    @PostMapping("payment")
    public ResponseEntity<ApiResponse> createPayment(@RequestBody PaymentReq paymentReq, @RequestHeader HttpHeaders headers) throws Exception {
        ApiResponse apiResponse = paymentService.createPayment(paymentReq, headers);
        return new ResponseEntity<>(apiResponse, apiResponse.getStatus());
    }

    @GetMapping("payment-status")
    public ResponseEntity<ApiResponse> getPayment(@RequestParam String transId, @RequestHeader HttpHeaders headers) throws Exception {
        ApiResponse apiResponse = paymentService.getPayment(transId, headers);
        return new ResponseEntity<>(apiResponse, apiResponse.getStatus());
    }
}
