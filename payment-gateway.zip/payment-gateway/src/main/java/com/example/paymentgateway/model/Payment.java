package com.example.paymentgateway.model;

import com.example.paymentgateway.enums.PaymentStatus;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Getter
@Setter
public class Payment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    private PaymentDetail paymentDetail;

    @Column(unique = true)
    private String transId;

    private Double totalAmt;

    @Enumerated(EnumType.STRING)
    @Column(columnDefinition = "character varying(255) default 'PENDING'")
    private PaymentStatus status = PaymentStatus.PENDING;

    private LocalDateTime paidOn;
}
