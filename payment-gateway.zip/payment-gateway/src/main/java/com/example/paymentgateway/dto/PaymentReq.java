package com.example.paymentgateway.dto;

import lombok.Getter;
import lombok.NonNull;
import lombok.Setter;

@Getter
@Setter
public class PaymentReq {

    @NonNull
    private String merchantUuid;

    private String cardNo;

    private String expiry;

    private Double totalAmt;
}
