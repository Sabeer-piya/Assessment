package com.example.paymentgateway.enums;

public enum CardType {

    VISA("visa"),
    MASTERCARD("mastercard"),
    AMEX("amex"),
    MAESTRO("maestro"),
    DISCOVER("discover"),
    UNKNOWN("unknown"),
    JCB("jcb"),
    DINERS_CLUB("diners-club"),
    ENROUTE("enroute"),
    INVALID("invalid");



    CardType(String enroute) {
    }
}
