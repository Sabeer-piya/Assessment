package com.example.paymentgateway.response;

import lombok.Getter;
import lombok.Setter;
import org.springframework.http.HttpStatus;

import java.sql.Timestamp;
import java.util.Date;

@Getter
@Setter
public class ApiResponse {

    private HttpStatus status;
    private String message;
    private Object data;
    private long timestamp = new Date().getTime();
    private int statusCode;

    public ApiResponse() {
    }

    public ApiResponse(HttpStatus status, String message) {
        this.status = status;
        this.message = message;
        this.statusCode = status.value();
    }

    public ApiResponse(HttpStatus status, String message, Object resultObject) {
        this.status = status;
        this.message = message;
        this.data = resultObject;
        this.timestamp = new Timestamp(new Date().getTime()).getTime();
        this.statusCode = status.value();
    }

    private ApiResponse(ApiResponseBuilder responseBuilder) {
        this.setStatus(responseBuilder.status);
        this.setMessage(responseBuilder.message);
        this.setData(responseBuilder.data);
        this.setTimestamp(responseBuilder.timestamp);
        this.setStatusCode(responseBuilder.status.value());
    }

    public boolean equals(Object o) {
        if (o == this)
            return true;
        if (!(o instanceof ApiResponse))
            return false;
        final ApiResponse other = (ApiResponse) o;
        if (!other.canEqual(this))
            return false;
        final Object this$status = this.getStatus();
        final Object other$status = other.getStatus();
        if (this$status == null ? other$status != null : !this$status.equals(other$status))
            return false;
        final Object this$message = this.getMessage();
        final Object other$message = other.getMessage();
        if (this$message == null ? other$message != null : !this$message.equals(other$message))
            return false;
        final Object this$data = this.getData();
        final Object other$data = other.getData();
        if (this$data == null ? other$data != null : !this$data.equals(other$data))
            return false;
        if (this.getTimestamp() != other.getTimestamp())
            return false;
        return this.getStatusCode() == other.getStatusCode();
    }

    public int hashCode() {
        final int PRIME = 59;
        int result = 1;
        final Object $status = this.getStatus();
        result = result * PRIME + ($status == null ? 43 : $status.hashCode());
        final Object $message = this.getMessage();
        result = result * PRIME + ($message == null ? 43 : $message.hashCode());
        final Object $data = this.getData();
        result = result * PRIME + ($data == null ? 43 : $data.hashCode());
        final long $timestamp = this.getTimestamp();
        result = result * PRIME + (int) ($timestamp >>> 32 ^ $timestamp);
        result = result * PRIME + this.getStatusCode();
        return result;
    }

    protected boolean canEqual(Object other) {
        return other instanceof ApiResponse;
    }

    public String toString() {
        return "ApiResponse(status=" + this.getStatus() + ", message=" + this.getMessage() + ", data=" + this.getData()
                + ", timestamp=" + this.getTimestamp() + ", statusCode="
                + this.getStatusCode() + ")";
    }

    public static class ApiResponseBuilder {
        private HttpStatus status;
        private String message;
        private Object data;
        private String error;
        private final long timestamp = System.currentTimeMillis();

        public ApiResponse build() {
            return new ApiResponse(this);
        }

        public ApiResponseBuilder setMessage(String message) {
            this.message = message;
            return this;
        }

        public ApiResponseBuilder setData(Object data) {
            this.data = data;
            return this;
        }

        public ApiResponseBuilder setError(String error) {
            this.error = error;
            return this;
        }

        public ApiResponseBuilder setStatus(HttpStatus status) {
            this.status = status;
            return this;
        }
    }

    public static ApiResponse getFailureResponse() {
        return new ApiResponse(HttpStatus.BAD_REQUEST, "Something Went wrong!");
    }

    public static ApiResponse getSuccessResponse() {
        return new ApiResponse(HttpStatus.OK, "Success");
    }
}
