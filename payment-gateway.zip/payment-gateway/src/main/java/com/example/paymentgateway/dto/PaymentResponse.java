package com.example.paymentgateway.dto;

import com.example.paymentgateway.constants.Constants;
import com.example.paymentgateway.model.Payment;
import com.example.paymentgateway.utils.Utility;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.format.DateTimeFormatter;

@Getter
@Setter
@NoArgsConstructor
public class PaymentResponse {

    private String transId;

    private String merchantId;

    private Double totalAmt;

    private String cardType;

    private String cardNo;

    private String cardExpiry;

    private String status;


    public PaymentResponse(Payment payment) {
        this.transId = payment.getTransId();
        this.status = payment.getStatus().name();
        this.merchantId = payment.getPaymentDetail().getMerchant().getUuid();
        this.totalAmt = payment.getTotalAmt();
        this.cardType = payment.getPaymentDetail().getCardType().name();
        this.cardNo = Utility.maskCardNumber(payment.getPaymentDetail().getCardNo());
        this.cardExpiry = payment.getPaymentDetail().getCardExpiry().format(DateTimeFormatter.ofPattern(Constants.DATE_FORMAT_MM_YY));
    }
}
