package com.example.paymentgateway.enums;

public enum PaymentStatus {

    PENDING, IN_PROGRESS, COMPLETED, FAILED
}
