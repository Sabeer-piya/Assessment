package com.example.paymentgateway.dto;

import lombok.Getter;
import lombok.Setter;
import org.springframework.lang.NonNull;

@Getter
@Setter
public class MerchantRequest {

    private String name;

    private String email;

    private String businessType;

    private String govtId;
}
