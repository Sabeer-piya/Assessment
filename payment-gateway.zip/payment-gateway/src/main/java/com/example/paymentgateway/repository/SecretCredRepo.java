package com.example.paymentgateway.repository;

import com.example.paymentgateway.model.SecretCred;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface SecretCredRepo extends JpaRepository<SecretCred, Long> {
    Boolean existsByAccessKeyAndSecretKeyAndIsActiveTrue(String accessKey, String secretKey);

    Boolean existsByAccessKey(String accessKey);

    Boolean existsBySecretKey(String accessKey);

    Optional<SecretCred> findByAccessKeyAndSecretKeyAndIsActiveTrue(String accessKey, String secretKey);
}
