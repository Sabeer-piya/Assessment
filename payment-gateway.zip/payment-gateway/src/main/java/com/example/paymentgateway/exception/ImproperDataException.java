package com.example.paymentgateway.exception;

public class ImproperDataException extends RuntimeException {
	private static final long serialVersionUID = 189354665892001269L;

	public ImproperDataException(String message) {
		super(message);
	}
}
