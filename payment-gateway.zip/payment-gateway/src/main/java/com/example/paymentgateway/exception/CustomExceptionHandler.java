package com.example.paymentgateway.exception;

import com.example.paymentgateway.response.ApiResponse;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.util.ArrayList;
import java.util.List;

@SuppressWarnings({"unchecked", "rawtypes"})
@ControllerAdvice
public class CustomExceptionHandler extends ResponseEntityExceptionHandler {

    @ExceptionHandler(PaymentGatewayCustomException.class)
    public final ResponseEntity<Object> handleWorkfallCustomExceptions(Exception ex, WebRequest request) {
        ApiResponse error = new ApiResponse(HttpStatus.BAD_REQUEST, ex.getMessage(), ex.getLocalizedMessage());
        ex.getLocalizedMessage();
        return new ResponseEntity(error, error.getStatus());
    }

    @ExceptionHandler(Exception.class)
    public final ResponseEntity<Object> handleAllExceptions(Exception ex, WebRequest request) {
        ApiResponse error;
        if ( ex.getMessage().equalsIgnoreCase("Access is denied") || ex.getLocalizedMessage().equalsIgnoreCase("Access is denied") ) {
            error = new ApiResponse(HttpStatus.UNAUTHORIZED,"You don't have permission to access this url", ex.getLocalizedMessage());
        } else {
            error = new ApiResponse(HttpStatus.INTERNAL_SERVER_ERROR, "Something went wrong", "Something went wrong");
        }
        ex.printStackTrace();
        return new ResponseEntity(error, error.getStatus());
    }
    @ResponseStatus(value = HttpStatus.UNAUTHORIZED)
    protected ResponseEntity<Object> handleMethodArgumentNotValid(Exception ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
        List<String> details = new ArrayList<>();
        ApiResponse error = new ApiResponse(HttpStatus.UNAUTHORIZED, ex.getLocalizedMessage(), details);
        return new ResponseEntity(error, error.getStatus());
    }

    protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
        List<String> details = new ArrayList<>();
        for (ObjectError error : ex.getBindingResult().getAllErrors()) {
            details.add(error.getDefaultMessage());
        }
        ApiResponse error = new ApiResponse(HttpStatus.BAD_REQUEST, "Validation Failed", details);
        return new ResponseEntity(error, error.getStatus());
    }
}
