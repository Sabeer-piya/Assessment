package com.example.paymentgateway.dto;

import com.example.paymentgateway.model.SecretCred;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class SecretResponse {

    private String uuid;

    private String secretKey;

    private String accessKey;

    public SecretResponse(SecretCred secretCred) {
        this.uuid = secretCred.getUuid();
        this.accessKey = secretCred.getAccessKey();
        this.secretKey = secretCred.getSecretKey();
    }
}
