package com.example.paymentgateway.constants;

public class Constants {
    public static final  String DATE_FORMAT_MM_YY = "MM/yy";
}
