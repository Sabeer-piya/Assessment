package com.example.paymentgateway.utils;

import com.example.paymentgateway.constants.Constants;
import com.example.paymentgateway.enums.CardType;
import org.springframework.util.StringUtils;

import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.Random;

public class Utility {

    public static String getRandomStringKey(int length) {
        char[] alphaChars = "123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ".toCharArray();
        Random random = new Random();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < length; i++) {
            char c = alphaChars[random.nextInt(alphaChars.length)];
            sb.append(c);
        }

        return sb.toString();
    }

    public static String getAccessRandomStringKey(int length) {
        char[] alphaChars = "123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ".toCharArray();
        Random random = new Random();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < length; i++) {
            char c = alphaChars[random.nextInt(alphaChars.length)];
            sb.append(c);
        }

        return sb.toString();
    }

    public static String getSecretRandomStringKey(int length) {
        char[] alphaChars = "123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ!@#$%^&*".toCharArray();
        Random random = new Random();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < length; i++) {
            char c = alphaChars[random.nextInt(alphaChars.length)];
            sb.append(c);
        }

        return sb.toString();
    }

    public static CardType identifyCardType(String cardNumber) {
        // Remove any non-numeric characters from the card number
        String cleanCardNumber = cardNumber.replaceAll("[^0-9]", "");

        // Check the card number length and the prefixes to determine the card type
        if (cleanCardNumber.length() >= 12 && cleanCardNumber.length() <= 19) {
            if (cleanCardNumber.startsWith("4")) {
                return CardType.VISA;
            } else if (cleanCardNumber.startsWith("5")) {
                return CardType.MASTERCARD;
            } else if (cleanCardNumber.startsWith("37") || cleanCardNumber.startsWith("34")) {
                return CardType.AMEX;
            } else if (cleanCardNumber.startsWith("6")) {
                return CardType.DISCOVER;
            } else if (cleanCardNumber.startsWith("35")) {
                return CardType.JCB;
            } else if (cleanCardNumber.startsWith("30") || cleanCardNumber.startsWith("36") || cleanCardNumber.startsWith("38")) {
                return CardType.DINERS_CLUB;
            }  else if (cleanCardNumber.startsWith("2014") || cleanCardNumber.startsWith("2149")) {
                return CardType.ENROUTE;
            } else if (cleanCardNumber.startsWith("50") || (Integer.parseInt(cleanCardNumber.substring(0, 2)) >= 56 && Integer.parseInt(cleanCardNumber.substring(0, 2)) <= 69) || (cleanCardNumber.length() >= 6 && Integer.parseInt(cleanCardNumber.substring(0, 6)) >= 600000 && Integer.parseInt(cleanCardNumber.substring(0, 6)) <= 699999)) {
                return CardType.MAESTRO;
            } else {
                return CardType.UNKNOWN;
            }
        } else {
            return CardType.INVALID;
        }
    }

    public static String maskCardNumber(String cardNumber) {
        int length = cardNumber.length();
        if (length <= 4) {
            return cardNumber; // If the card number is 4 digits or less, return it as it is
        }
        // Mask all but the last four digits
        StringBuilder masked = new StringBuilder();
        for (int i = 0; i < length - 4; i++) {
            masked.append('x');
        }
        // Append the last four digits
        masked.append(cardNumber.substring(length - 4));
        return masked.toString();
    }

    public static LocalDate getExpiryMonth(String expiryDate){
        YearMonth yearMonth = YearMonth.parse(expiryDate, DateTimeFormatter.ofPattern(Constants.DATE_FORMAT_MM_YY));
        return yearMonth.atDay(1);
    }
}
