package com.example.paymentgateway.repository;

import com.example.paymentgateway.model.Merchant;
import com.example.paymentgateway.model.PaymentDetail;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface PaymentDetailRepo extends JpaRepository<PaymentDetail, Long> {
    Optional<PaymentDetail> findByMerchantAndCardNo(Merchant merchant, String cardNo);
}
