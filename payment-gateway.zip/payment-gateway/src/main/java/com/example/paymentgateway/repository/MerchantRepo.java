package com.example.paymentgateway.repository;

import com.example.paymentgateway.model.Merchant;
import com.example.paymentgateway.model.SecretCred;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
@EnableJpaRepositories
public interface MerchantRepo extends JpaRepository<Merchant,Long> {
    Boolean existsByUuid(String uuid);

    Optional<Merchant> findByUuid(String merchantUuid);

    Optional<Merchant> findByUuidAndSecretCred(String merchantUuid, SecretCred secretCred);
}
