package com.example.paymentgateway.service;

import com.example.paymentgateway.dto.MerchantRequest;
import com.example.paymentgateway.dto.PaymentReq;
import com.example.paymentgateway.response.ApiResponse;
import org.springframework.http.HttpHeaders;

public interface PaymentService {

    ApiResponse createMerchant(MerchantRequest merchantRequest, HttpHeaders headers) throws Exception;

    ApiResponse createSecret();

    ApiResponse createPayment(PaymentReq paymentReq, HttpHeaders headers) throws Exception;

    ApiResponse getPayment(String transId, HttpHeaders headers) throws Exception;
}
