package com.example.paymentgateway.model;

import com.example.paymentgateway.enums.CardType;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;


import java.time.LocalDate;

@Entity
@Getter
@Setter
public class PaymentDetail {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    private Merchant merchant;

    private String cardNo;

    @Enumerated(EnumType.STRING)
    private CardType cardType;

    private LocalDate cardExpiry;
}
